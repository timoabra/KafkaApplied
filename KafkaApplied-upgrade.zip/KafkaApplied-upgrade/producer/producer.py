#!/usr/bin/env python3
import argparse, json, time, random, datetime
from kafka import KafkaProducer

def main(broker, topic, minutes, rps):
    prod = KafkaProducer(bootstrap_servers=[broker],
                         value_serializer=lambda v: json.dumps(v).encode("utf-8"))
    t_end = time.time() + minutes*60
    sent = 0
    while time.time() < t_end:
        msg = {
            "ts": datetime.datetime.now().isoformat(),
            "car_id": f"C{random.randint(1000,9999)}",
            "speed_mph": max(0, min(int(random.gauss(60, 10)), 130)),
            "lane": random.randint(1,4)
        }
        prod.send(topic, msg)
        sent += 1
        if sent % rps == 0:
            # pace to rps
            time.sleep(1)
    prod.flush()
    print(f"Sent ~{sent} messages to {topic}")

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--broker", default="localhost:9092")
    ap.add_argument("--topic", default="car-events")
    ap.add_argument("--minutes", type=int, default=18)
    ap.add_argument("--rps", type=int, default=8, help="events per second")
    args = ap.parse_args()
    main(args.broker, args.topic, args.minutes, args.rps)
