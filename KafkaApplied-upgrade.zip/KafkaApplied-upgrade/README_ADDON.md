# KafkaApplied – Streaming vs No-Streaming Comparison

This package adds a **Kafka vs No-Kafka** pipeline, a **Highcharts** dashboard, and a **10,000-row CSV** generator to your repo.

## What’s included
- `docker-compose.yml` for **Kafka + Zookeeper + MySQL + Flask app**
- `schema.sql` to create two tables:
  - `events_live` (ingested via Kafka consumer)
  - `events_direct` (inserted without Kafka, simulating the baseline)
- `producer/producer.py`: streams events to Kafka (configurable rate/duration)
- `consumers/consumer_kafka.py`: reads Kafka, writes to MySQL
- `consumers/consumer_nokafka.py`: writes directly to MySQL (bypasses Kafka)
- `app/` Flask app with Highcharts showing **% of cars above speed threshold**, Kafka vs No-Kafka
- `data/generate_csv.py`: creates **10,000 rows** by default (`data/events_10k.csv`)

## Quick start (local, with Docker)
Prereqs: Docker + Docker Compose installed.

```bash
# 1) Start infra (Kafka, ZK, MySQL) and the Flask app
docker compose up -d

# 2) Initialize DB schema
docker exec -i kafkaapplied-db mysql -uroot -prootpass kafkaapplied < schema.sql

# 3) (Optional) Generate a fresh 10k-row CSV
python data/generate_csv.py --rows 10000 --outfile data/events_10k.csv

# 4) Run baseline (No-Kafka) writer against 10k CSV
python consumers/consumer_nokafka.py --csv data/events_10k.csv --batch 500

# 5) Run the Kafka producer for ~15-20 minutes (configurable)
python producer/producer.py --minutes 18 --rps 8

# 6) Start the Kafka consumer to write into MySQL
python consumers/consumer_kafka.py
```

Open the dashboard at **http://localhost:5000** → it will show **Kafka vs No-Kafka %>speed_threshold**.

> Speed threshold defaults to **65 mph**. You can change it in `.env` or via query param `?threshold=70` on the dashboard.

## Tuning for 15–20 minutes runtime
- Use `--minutes` and `--rps` (records per second) flags on `producer.py`.
- Example: `--minutes 18 --rps 8` yields ~8 * 60 * 18 ≈ 8,640 live events.

## Add to your GitHub repo
```bash
# from your KafkaApplied repo root
cp -r KafkaApplied-upgrade/* .

git add .
git commit -m "Add Kafka vs No-Kafka pipeline, dashboard, and 10k CSV generator"
git push origin main
```

## Environment
- MySQL root password: `rootpass` (dev only)
- DB: `kafkaapplied`
- Kafka broker: `kafka:9092`
- Topic: `car-events`

## Notes
- Containers are defined for local dev. In production, point to managed Kafka/MySQL and run the Flask app separately.
- If ports are busy, edit `docker-compose.yml`.
