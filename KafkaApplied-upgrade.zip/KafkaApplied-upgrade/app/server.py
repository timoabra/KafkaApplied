from flask import Flask, render_template, request, jsonify
import os, pymysql

app = Flask(__name__)

def get_db():
    return pymysql.connect(
        host=os.getenv("DB_HOST","localhost"),
        user=os.getenv("DB_USER","root"),
        password=os.getenv("DB_PASS","rootpass"),
        database=os.getenv("DB_NAME","kafkaapplied"),
        cursorclass=pymysql.cursors.DictCursor
    )

@app.route("/")
def index():
    threshold = int(request.args.get("threshold", 65))
    return render_template("index.html", threshold=threshold)

@app.route("/api/percentages")
def api_percentages():
    threshold = int(request.args.get("threshold", 65))
    conn = get_db()
    with conn.cursor() as cur:
        cur.execute("SELECT COUNT(*) AS n FROM events_live")
        live_n = cur.fetchone()["n"]
        cur.execute("SELECT COUNT(*) AS n FROM events_live WHERE speed_mph > %s", (threshold,))
        live_pass = cur.fetchone()["n"]

        cur.execute("SELECT COUNT(*) AS n FROM events_direct")
        dir_n = cur.fetchone()["n"]
        cur.execute("SELECT COUNT(*) AS n FROM events_direct WHERE speed_mph > %s", (threshold,))
        dir_pass = cur.fetchone()["n"]

    pct_live = (live_pass/live_n*100.0) if live_n else 0.0
    pct_direct = (dir_pass/dir_n*100.0) if dir_n else 0.0
    return jsonify({
        "threshold": threshold,
        "kafka_pct": round(pct_live,2),
        "direct_pct": round(pct_direct,2),
        "live_n": live_n,
        "direct_n": dir_n
    })

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
