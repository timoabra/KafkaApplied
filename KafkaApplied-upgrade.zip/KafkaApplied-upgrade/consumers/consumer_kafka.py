#!/usr/bin/env python3
import os, json, argparse
from kafka import KafkaConsumer
from db import get_conn

def consume(broker, topic, group_id="car-consumers"):
    consumer = KafkaConsumer(
        topic,
        bootstrap_servers=[broker],
        group_id=group_id,
        value_deserializer=lambda v: json.loads(v.decode("utf-8")),
        auto_offset_reset="earliest",
        enable_auto_commit=True
    )
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("CREATE TABLE IF NOT EXISTS events_live (id BIGINT AUTO_INCREMENT PRIMARY KEY, ts TIMESTAMP NOT NULL, car_id VARCHAR(16) NOT NULL, speed_mph INT NOT NULL, lane TINYINT NOT NULL, has_kafka TINYINT NOT NULL DEFAULT 1)")
    q = "INSERT INTO events_live (ts,car_id,speed_mph,lane,has_kafka) VALUES (%s,%s,%s,%s,1)"
    count = 0
    for msg in consumer:
        m = msg.value
        cur.execute(q, (m["ts"], m["car_id"], int(m["speed_mph"]), int(m["lane"])))
        count += 1
        if count % 1000 == 0:
            print(f"Ingested {count} events")
    print("Kafka consumer stopped.")

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--broker", default="localhost:9092")
    ap.add_argument("--topic", default="car-events")
    args = ap.parse_args()
    consume(args.broker, args.topic)
