#!/usr/bin/env python3
import csv, random, argparse, datetime

def generate(rows, outpath, seed=42):
    random.seed(seed)
    with open(outpath, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["ts","car_id","speed_mph","lane"])
        t0 = datetime.datetime.now()
        for i in range(rows):
            ts = t0 + datetime.timedelta(seconds=i%1200)  # cycle through ~20 minutes
            car = f"C{random.randint(1000,9999)}"
            speed = int(random.gauss(60, 10))  # mean 60, sd 10
            speed = max(0, min(speed, 120))
            lane = random.randint(1,4)
            w.writerow([ts.isoformat(), car, speed, lane])

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--rows", type=int, default=10000)
    ap.add_argument("--outfile", type=str, default="data/events_10k.csv")
    args = ap.parse_args()
    generate(args.rows, args.outfile)
    print(f"Wrote {args.rows} rows to {args.outfile}")
