#!/usr/bin/env python3
import argparse, csv
from db import get_conn

def write_realistic(csv_path, batch=500):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("""CREATE TABLE IF NOT EXISTS events_realistic (
        id BIGINT AUTO_INCREMENT PRIMARY KEY,
        ts TIMESTAMP NOT NULL,
        pmgid VARCHAR(16) NOT NULL,
        street VARCHAR(64) NOT NULL,
        car_id VARCHAR(16) NOT NULL,
        speed_mph INT NOT NULL,
        lane TINYINT NOT NULL,
        has_kafka TINYINT NOT NULL)""")
    q = "INSERT INTO events_realistic (ts,pmgid,street,car_id,speed_mph,lane,has_kafka) VALUES (%s,%s,%s,%s,%s,%s,0)"
    buf = []
    with open(csv_path, newline="") as f:
        r = csv.DictReader(f)
        for row in r:
            buf.append((row["ts"], row["pmgid"], row["street"], row["car_id"], int(row["speed_mph"]), int(row["lane"])))
            if len(buf) >= batch:
                cur.executemany(q, buf); buf.clear()
        if buf: cur.executemany(q, buf)
    print("Realistic direct ingest complete.")

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", default="data/events_realistic_10k.csv")
    ap.add_argument("--batch", type=int, default=500)
    args = ap.parse_args()
    write_realistic(args.csv, args.batch)
