#!/usr/bin/env python3
import csv, argparse, random, datetime

STREETS = ["Main St", "Elm St", "Maple Ave", "Oak St", "Pine Ave", "Cedar Rd", "1st Ave", "2nd Ave", "3rd Ave", "Central Blvd", "Market St", "Broadway", "Sunset Blvd", "Lakeview Dr", "Ridge Rd", "Park Ave", "River Rd", "Hillcrest Dr", "Walnut St", "Birch Ln"]

def tod_speed_mean(dt: datetime.datetime) -> float:
    weekday = dt.weekday()  # 0=Mon..6=Sun
    is_weekend = weekday >= 5
    hour = dt.hour
    mean = 60.0
    if not is_weekend and (7 <= hour <= 9 or 16 <= hour <= 18):
        mean = 38.0
    elif 10 <= hour <= 15:
        mean = 55.0
    elif 19 <= hour <= 22:
        mean = 50.0
    elif hour >= 23 or hour <= 5:
        mean = 68.0
    if is_weekend:
        if 12 <= hour <= 17:
            mean = 52.0
        else:
            mean = 65.0
    return mean

def clamp(x, lo, hi):
    return max(lo, min(hi, x))

def burst(rows, seed, outfile, pmgid="PM001"):
    random.seed(seed)
    t0 = datetime.datetime.now().replace(microsecond=0)
    with open(outfile, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["ts","pmgid","street","car_id","speed_mph","lane"])
        i = 0
        while i < rows:
            b = random.randint(3,5)
            street = random.choice(STREETS)
            for _ in range(b):
                if i >= rows: break
                ts = t0 + datetime.timedelta(seconds=i%1800)
                mean = tod_speed_mean(ts)
                speed = int(random.gauss(mean, 8))
                speed = clamp(speed, 0, 120)
                car = f"C{random.randint(1000,9999)}"
                lane = random.randint(1,4)
                w.writerow([ts.isoformat(), pmgid, street, car, speed, lane])
                i += 1

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--rows", type=int, default=10000)
    ap.add_argument("--outfile", type=str, default="data/events_realistic_10k.csv")
    ap.add_argument("--pmgid", type=str, default="PM001")
    ap.add_argument("--seed", type=int, default=1337)
    args = ap.parse_args()
    burst(args.rows, args.seed, args.outfile, pmgid=args.pmgid)
    print(f"Wrote {args.rows} realistic rows to {args.outfile}")
