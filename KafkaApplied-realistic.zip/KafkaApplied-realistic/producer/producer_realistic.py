#!/usr/bin/env python3
import argparse, json, time, random, datetime
from kafka import KafkaProducer

STREETS = ["Main St", "Elm St", "Maple Ave", "Oak St", "Pine Ave", "Cedar Rd", "1st Ave", "2nd Ave", "3rd Ave", "Central Blvd", "Market St", "Broadway", "Sunset Blvd", "Lakeview Dr", "Ridge Rd", "Park Ave", "River Rd", "Hillcrest Dr", "Walnut St", "Birch Ln"]

def tod_speed_mean(dt):
    weekday = dt.weekday()
    is_weekend = weekday >= 5
    hour = dt.hour
    mean = 60.0
    if not is_weekend and (7 <= hour <= 9 or 16 <= hour <= 18):
        mean = 38.0
    elif 10 <= hour <= 15:
        mean = 55.0
    elif 19 <= hour <= 22:
        mean = 50.0
    elif hour >= 23 or hour <= 5:
        mean = 68.0
    if is_weekend:
        if 12 <= hour <= 17:
            mean = 52.0
        else:
            mean = 65.0
    return mean

def main(broker, topic, minutes, rps, pmgid):
    prod = KafkaProducer(bootstrap_servers=[broker],
                         value_serializer=lambda v: json.dumps(v).encode("utf-8"))
    t_end = time.time() + minutes*60
    sent = 0
    while time.time() < t_end:
        b = random.randint(3,5)
        for _ in range(b):
            now = datetime.datetime.now().replace(microsecond=0)
            mean = tod_speed_mean(now)
            speed = int(max(0, min(120, random.gauss(mean, 8))))
            msg = {
                "ts": now.isoformat(),
                "pmgid": pmgid,
                "street": random.choice(STREETS),
                "car_id": f"C{random.randint(1000,9999)}",
                "speed_mph": speed,
                "lane": random.randint(1,4)
            }
            prod.send(topic, msg)
            sent += 1
        time.sleep(max(0, 1.0 - b/float(max(rps,1))))
    prod.flush()
    print(f"Sent ~{sent} messages to {topic}")

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--broker", default="localhost:9092")
    ap.add_argument("--topic", default="car-events-realistic")
    ap.add_argument("--minutes", type=int, default=18)
    ap.add_argument("--rps", type=int, default=8)
    ap.add_argument("--pmgid", type=str, default="PM001")
    args = ap.parse_args()
    main(args.broker, args.topic, args.minutes, args.rps, args.pmgid)
