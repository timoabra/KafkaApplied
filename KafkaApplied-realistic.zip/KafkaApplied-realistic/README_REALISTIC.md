
# Realistic Generator Add-on

Implements more realistic event generation in a **separate pipeline** so the current one stays intact.

**Behaviors**
- One `pmgid` (sensor) emits **bursts of 3–5 cars** per tick.
- **Street names** from a finite catalog (not 1–1000 random locations).
- **Time-of-day speed profile**: rush hours slower, late nights faster, weekends different.
- Writes into **`events_realistic`** (new table).

**Pipelines**
- `producer_realistic.py` → Kafka topic `car-events-realistic` → `consumer_kafka_realistic.py` → MySQL
- `generator_realistic.py` → CSV → `consumer_realistic_nokafka.py` → MySQL
