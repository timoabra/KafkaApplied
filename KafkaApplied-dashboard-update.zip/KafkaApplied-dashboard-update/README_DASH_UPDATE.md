
# Dashboard update
- Adds a **third series** for `events_realistic`.
- Adds **filters** for `pmgid` and `street`.
- New API: `/api/percentages_all?threshold=65&pmgid=PM001&street=Main%20St` and `/api/options`.
