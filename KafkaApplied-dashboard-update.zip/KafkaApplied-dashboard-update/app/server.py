
from flask import Flask, render_template, request, jsonify
import os, pymysql

app = Flask(__name__)

def get_db():
    return pymysql.connect(
        host=os.getenv("DB_HOST","localhost"),
        user=os.getenv("DB_USER","root"),
        password=os.getenv("DB_PASS","rootpass"),
        database=os.getenv("DB_NAME","kafkaapplied"),
        cursorclass=pymysql.cursors.DictCursor
    )

@app.route("/")
def index():
    # threshold, pmgid, street are optional; UI will query APIs for options
    threshold = int(request.args.get("threshold", 65))
    pmgid = request.args.get("pmgid", "")
    street = request.args.get("street", "")
    return render_template("index.html", threshold=threshold, pmgid=pmgid, street=street)

def count_pct(cur, table, threshold, pmgid=None, street=None):
    where = []
    params = []
    if threshold is not None:
        where.append("speed_mph > %s")
        params.append(threshold)
    if pmgid:
        where.append("pmgid = %s")
        params.append(pmgid)
    if street:
        where.append("street = %s")
        params.append(street)
    where_clause = ("WHERE " + " AND ".join(where)) if where else ""
    cur.execute(f"SELECT COUNT(*) AS n FROM {table}")
    total = cur.fetchone()["n"]
    cur.execute(f"SELECT COUNT(*) AS n FROM {table} {where_clause}", params)
    passed = cur.fetchone()["n"]
    return total, (passed/total*100.0 if total else 0.0)

@app.route("/api/options")
def api_options():
    conn = get_db()
    data = {"pmgids": [], "streets": []}
    with conn.cursor() as cur:
        # pull distinct pmgids/streets from realistic table if present, fallback to others
        try:
            cur.execute("SELECT DISTINCT pmgid FROM events_realistic ORDER BY pmgid")
            data["pmgids"] = [r["pmgid"] for r in cur.fetchall()]
        except Exception:
            data["pmgids"] = []
        try:
            cur.execute("SELECT DISTINCT street FROM events_realistic ORDER BY street")
            data["streets"] = [r["street"] for r in cur.fetchall()]
        except Exception:
            data["streets"] = []
    return jsonify(data)

@app.route("/api/percentages_all")
def api_percentages_all():
    threshold = int(request.args.get("threshold", 65))
    pmgid = request.args.get("pmgid") or None
    street = request.args.get("street") or None
    conn = get_db()
    out = {}
    with conn.cursor() as cur:
        # No-Kafka baseline
        try:
            total, pct = count_pct(cur, "events_direct", threshold)
            out["direct_pct"] = round(pct,2); out["direct_n"] = total
        except Exception:
            out["direct_pct"] = 0.0; out["direct_n"] = 0
        # Kafka live
        try:
            total, pct = count_pct(cur, "events_live", threshold)
            out["kafka_pct"] = round(pct,2); out["kafka_n"] = total
        except Exception:
            out["kafka_pct"] = 0.0; out["kafka_n"] = 0
        # Realistic
        try:
            total, pct = count_pct(cur, "events_realistic", threshold, pmgid=pmgid, street=street)
            out["realistic_pct"] = round(pct,2); out["realistic_n"] = total
        except Exception:
            out["realistic_pct"] = 0.0; out["realistic_n"] = 0
    out["threshold"] = threshold
    out["pmgid"] = pmgid
    out["street"] = street
    return jsonify(out)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
