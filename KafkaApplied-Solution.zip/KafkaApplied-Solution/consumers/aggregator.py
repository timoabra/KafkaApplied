#!/usr/bin/env python3
import time,datetime,argparse
from db import get_conn
def aggregate(window=5,source='kafka'):
  raw='events_live' if source=='kafka' else 'events_direct'
  metrics='metrics_kafka' if source=='kafka' else 'metrics_direct'
  conn=get_conn(); cur=conn.cursor()
  cur.execute(f"""CREATE TABLE IF NOT EXISTS {metrics} (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    pmgid VARCHAR(16) NOT NULL,
    vehicle_count INT NOT NULL,
    pepkspeed INT NOT NULL,
    timestamp TIMESTAMP NOT NULL,
    location VARCHAR(64) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
  )""")
  while True:
    now=datetime.datetime.utcnow().replace(microsecond=0); start=now-datetime.timedelta(seconds=window)
    cur.execute(f"""SELECT pmgid, location, COUNT(*) as vehicle_count, MAX(speed_mph) as pepkspeed
                     FROM {raw} WHERE ts >= %s AND ts < %s GROUP BY pmgid, location""", (start,now))
    for pmgid,loc,count,peak in cur.fetchall():
      cur.execute(f"""INSERT INTO {metrics} (pmgid,vehicle_count,pepkspeed,timestamp,location)
                  VALUES (%s,%s,%s,%s,%s)""", (pmgid,int(count),int(peak or 0),now,loc))
    time.sleep(window)
if __name__=='__main__':
  ap=argparse.ArgumentParser(); ap.add_argument('--window',type=int,default=5); ap.add_argument('--source',choices=['kafka','direct'],default='kafka')
  a=ap.parse_args(); aggregate(a.window,a.source)
