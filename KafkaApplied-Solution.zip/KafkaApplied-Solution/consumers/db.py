import os, mysql.connector
def get_conn():
    return mysql.connector.connect(
        host=os.getenv("DB_HOST","localhost"),
        user=os.getenv("DB_USER","root"),
        password=os.getenv("DB_PASS","rootpass"),
        database=os.getenv("DB_NAME","kafkaapplied"),
        autocommit=True
    )
