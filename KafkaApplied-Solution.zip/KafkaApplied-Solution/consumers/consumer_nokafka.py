#!/usr/bin/env python3
import argparse,csv
from db import get_conn
def ingest(csv_path,batch=500):
  conn=get_conn(); cur=conn.cursor()
  cur.execute("CREATE TABLE IF NOT EXISTS events_direct (id BIGINT AUTO_INCREMENT PRIMARY KEY, ts TIMESTAMP NOT NULL, pmgid VARCHAR(16) NOT NULL, location VARCHAR(64) NOT NULL, car_id VARCHAR(16) NOT NULL, speed_mph INT NOT NULL, lane TINYINT NOT NULL)")
  q="INSERT INTO events_direct (ts,pmgid,location,car_id,speed_mph,lane) VALUES (%s,%s,%s,%s,%s,%s)"
  buf=[]
  with open(csv_path,newline='') as f:
    r=csv.DictReader(f)
    for row in r:
      buf.append((row['ts'],row['pmgid'],row['location'],row['car_id'],int(row['speed_mph']),int(row['lane'])))
      if len(buf)>=batch: cur.executemany(q,buf); buf.clear()
    if buf: cur.executemany(q,buf)
if __name__=='__main__':
  ap=argparse.ArgumentParser(); ap.add_argument('--csv',default='data/events_10k.csv'); ap.add_argument('--batch',type=int,default=500)
  a=ap.parse_args(); ingest(a.csv,a.batch)
