#!/usr/bin/env python3
import csv, random, argparse, datetime
STREETS = ["Main St", "Elm St", "Maple Ave", "Oak St", "Pine Ave", "Cedar Rd", "1st Ave", "2nd Ave", "3rd Ave", "Central Blvd"]
def generate(rows,outpath,pmgid='PM001',seed=1337):
  random.seed(seed); t0=datetime.datetime.now().replace(microsecond=0)
  with open(outpath,'w',newline='') as f:
    w=csv.writer(f); w.writerow(['ts','pmgid','location','car_id','speed_mph','lane'])
    i=0
    while i<rows:
      b=random.randint(3,5); loc=random.choice(STREETS)
      for _ in range(b):
        if i>=rows: break
        ts=t0+datetime.timedelta(seconds=i%1800)
        w.writerow([ts.isoformat(),pmgid,loc,f"C{random.randint(1000,9999)}",max(0,min(int(random.gauss(60,10)),120)),random.randint(1,4)]); i+=1
if __name__=='__main__':
  ap=argparse.ArgumentParser(); ap.add_argument('--rows',type=int,default=10000); ap.add_argument('--outfile',default='data/events_10k.csv'); ap.add_argument('--pmgid',default='PM001')
  a=ap.parse_args(); generate(a.rows,a.outfile,a.pmgid); print('ok')
