from flask import Flask, render_template, request, jsonify
import os, pymysql
app=Flask(__name__)
def get_db():
  return pymysql.connect(host=os.getenv('DB_HOST','localhost'), user=os.getenv('DB_USER','root'),
                         password=os.getenv('DB_PASS','rootpass'), database=os.getenv('DB_NAME','kafkaapplied'),
                         cursorclass=pymysql.cursors.DictCursor)
def pct_over(cur,table,th):
  cur.execute(f"SELECT COUNT(*) n FROM {table}"); n=cur.fetchone()['n']
  cur.execute(f"SELECT COUNT(*) n FROM {table} WHERE speed_mph > %s",(th,)); k=cur.fetchone()['n']
  return (k/n*100.0 if n else 0.0), n
@app.route('/'); 
def index(): th=int(request.args.get('threshold',65)); return render_template('index.html',threshold=th)
@app.route('/api/percentages')
def api_percentages():
  th=int(request.args.get('threshold',65)); out={}
  conn=get_db()
  with conn.cursor() as cur:
    try: p,n=pct_over(cur,'events_direct',th); out.update(direct_pct=round(p,2),direct_n=n)
    except Exception: out.update(direct_pct=0.0,direct_n=0)
    try: p,n=pct_over(cur,'events_live',th); out.update(kafka_pct=round(p,2),kafka_n=n)
    except Exception: out.update(kafka_pct=0.0,kafka_n=0)
  out['threshold']=th; return jsonify(out)
if __name__=='__main__': app.run(host='0.0.0.0',port=5000,debug=True)
