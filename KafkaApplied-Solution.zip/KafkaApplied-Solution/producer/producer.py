#!/usr/bin/env python3
import argparse,json,time,random,datetime
from kafka import KafkaProducer
STREETS=['Main St','Elm St','Maple Ave','Oak St','Pine Ave','Cedar Rd','1st Ave','2nd Ave','3rd Ave','Central Blvd']
def main(broker,topic,minutes,rps,pmgid):
  prod=KafkaProducer(bootstrap_servers=[broker],value_serializer=lambda v: json.dumps(v).encode('utf-8'))
  end=time.time()+minutes*60
  while time.time()<end:
    b=random.randint(3,5)
    for _ in range(b):
      now=datetime.datetime.now().replace(microsecond=0)
      msg={'ts':now.isoformat(),'pmgid':pmgid,'location':random.choice(STREETS),'car_id':f"C{random.randint(1000,9999)}",'speed_mph':max(0,min(int(random.gauss(60,10)),120)),'lane':random.randint(1,4)}
      prod.send(topic,msg)
    time.sleep(max(0,1.0-b/float(max(rps,1))))
  prod.flush()
if __name__=='__main__':
  ap=argparse.ArgumentParser(); ap.add_argument('--broker',default='localhost:9092'); ap.add_argument('--topic',default='car-events'); ap.add_argument('--minutes',type=int,default=18); ap.add_argument('--rps',type=int,default=8); ap.add_argument('--pmgid',default='PM001')
  a=ap.parse_args(); main(a.broker,a.topic,a.minutes,a.rps,a.pmgid)
