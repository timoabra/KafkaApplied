# KafkaApplied — Solved

See instructions inside.
